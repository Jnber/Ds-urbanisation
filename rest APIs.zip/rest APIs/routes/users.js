var express = require("express");
var router = express.Router();

router.get("/getAllEmployee", (req, res) => {
  const query = {
    text: "select * from employees",
    values: [],
  };
  client
    .query(query)
    .then((response) => res.status(200).send(response.data))
    .catch((e) => res.status(400).send(e));
});

router.get("/getEmployeeById", (req, res) => {
  const query = {
    text: "select * from employees where id = $1",
    values: [req.query.id],
  };
  client
    .query(query)
    .then((response) => res.status(200).send(response.data))
    .catch((e) => res.status(400).send(e));
});

router.put("/update/:id", (req, res) => {
  const query = {
    text: "update employees set name = $2, salary = $3 where id = $1",
    values: [req.query.id, req.body.name, req.body.salary],
  };
  client
    .query(query)
    .then((response) => res.status(200).send(response.data))
    .catch((e) => res.status(400).send(e));
});

router.post("/addEmployee", (req, res) => {
  const query = {
    text: "insert into employees (name, salary) values($1,$2)",
    values: [req.body.name, req.body.salary],
  };
  client
    .query(query)
    .then((response) => res.status(200).send(response.data))
    .catch((e) => res.status(400).send(e));
});

module.exports = router;
